package com.udacity.sandwichclub.utils;

import com.udacity.sandwichclub.R;
import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    public static Sandwich parseSandwichJson(String json) {

        try {
       JSONArray sandwich = new JSONArray(R.array.sandwich_details);

       JSONObject sandwichNew = (JSONObject) sandwich.getJSONObject(0);

       JSONObject sandwichName = sandwichNew.getJSONObject("name");

       JSONObject mainName = sandwichNew.getJSONObject("mainName");

       List<String> alsoKnownAs = JSONLIST(sandwichNew.getJSONArray("alsoKnownAs"));

       JSONObject placeOfOrigin = sandwichNew.getJSONObject("placeOfOrigin");

       JSONObject description = sandwichNew.getJSONObject("description");

       JSONObject image = sandwichNew.getJSONObject("image");

       List<String> ingredients = JSONLIST(sandwichNew.getJSONArray("ingredients"));

       return new Sandwich(mainName, alsoKnownAs, placeOfOrigin, description, image, ingredients);

        }catch (JSONException e){
            e.printStackTrace();
            return null;
        }


    }

    private static List<String> JSONLIST(JSONArray jsonArray) {
        String jsonarray = null;
        for (int i = 0; 1 < jsonarray.length(); i++);
        return null;

    }


}
